import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-contact',
  templateUrl: './profile-contact.component.html',
  styleUrls: ['./profile-contact.component.scss']
})
export class ProfileContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
