import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-application',
  templateUrl: './profile-application.component.html',
  styleUrls: ['./profile-application.component.scss']
})
export class ProfileApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
