import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-university-course-detail',
  templateUrl: './university-course-detail.component.html',
  styleUrls: ['./university-course-detail.component.scss']
})
export class UniversityCourseDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
