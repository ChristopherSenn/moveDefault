export class Fact {
    // icon: String;
    title: String;
    description: String;
  }
