export class Experience {
    student: String;
    text: String;
    course: String;
  }
