export class Course {
    title: String;
    description: String;
    are: String;
    been: String;
  }
